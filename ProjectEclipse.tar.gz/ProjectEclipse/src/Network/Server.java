package Network;

public class Server {

	private int messageCode;
	
	
	public void ConnectionRequestAnswer()
	{
		
	}
	
	public int getMessageCode()
	{
		return messageCode;
	}
	
	public void CloseServer()
	{
		
	}
	
}
