package Network;

public class Client {

	public void RequestConnection()
	{
		
	}
	
	public void SendRequest()
	{
		
	}
	
	public void ClientDisconnect()
	{
		
	}
}
