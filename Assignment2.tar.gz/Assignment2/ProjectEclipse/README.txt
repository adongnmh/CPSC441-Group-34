CPSC441 - README

STEPS:
1.Please have the latest version of eclipse downloaded and installed 
2.unzip the assignment2.tar.gz file
3.Unzip the assignment2.tar file
4.Open Ecipse
5.File -> Import -> General -> Exisiting Projects into Workspace
6.In the import window, pick the "Select root directory". Next browse for the ProjectEclipse folder that we unzipped
in step 3. Next select all and then click finish.
7. Next run the CollobrativeDrawingController.java by using the run button.